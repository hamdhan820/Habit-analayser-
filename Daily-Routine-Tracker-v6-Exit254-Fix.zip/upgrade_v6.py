from pathlib import Path
p=Path('index.html'); s=p.read_text()
# Fix blocking safety: empty configured list must not block all apps
s=s.replace('    // Empty configuration means block normal user apps by default; allow essential system apps above.\n    if (configured != null && !configured.isEmpty() && !configured.contains(pkg)) return;', '    // Safety: never block every app by default. Only redirect apps the user explicitly selected.\n    if (configured == null || configured.isEmpty() || !configured.contains(pkg)) return;') if False else s
# Add tomorrow planner function before card
marker='function card(x){'
insert=r'''function planTomorrow(){
 const d=pd(today);d.setDate(d.getDate()+1);const dt=ymd(d),p=S.set.profile||{};
 modal('🌙 Plan tomorrow before sleep',[{k:'className',l:'Class / tuition name (leave blank if no class)',v:S.set.className||'Class'},{k:'classStart',l:'What time does class start?',t:'time',v:S.set.classStart||'08:30'},{k:'classEnd',l:'What time does class finish?',t:'time',v:S.set.classEnd||'17:30'},{k:'classDays',l:'Which days do you have class? Select days to repeat',t:'days',v:S.set.classDays||[1,2,3,4,5,6,0]},{k:'subjects',l:'Subjects / topics to study tomorrow',v:S.set.tomorrowSubjects||p.subjects||'Biology, Chemistry, Physics'},{k:'studyMins',l:'Study time per subject (minutes)',t:'number',v:String(S.set.studyMins||35)}],v=>{
 const subs=v.subjects.split(',').map(x=>x.trim()).filter(Boolean).slice(0,4);if(!v.classStart||!v.classEnd){alert('Please enter the class start and finish times.');return false}if(mm(v.classEnd)<=mm(v.classStart)){alert('Class finish time must be after the start time.');return false}if(!subs.length){alert('Add at least one subject or topic.');return false}
 S.set.className=v.className.trim()||'Class';S.set.classStart=v.classStart;S.set.classEnd=v.classEnd;S.set.classDays=v.classDays;S.set.tomorrowSubjects=v.subjects;S.set.studyMins=Math.max(15,Math.min(120,+v.studyMins||35));
 // Add/update the class as a recurring activity, based on the user's explicit schedule.
 let cls=S.acts.find(a=>a.isUserClass);if(!cls){cls={id:'classplan'+Date.now(),name:S.set.className,cat:'class',date:dt,s:v.classStart,e:v.classEnd,rem:10,rep:v.classDays,pri:'high',notes:'Class time entered by you.',isUserClass:true};S.acts.push(cls)}else Object.assign(cls,{name:S.set.className,date:dt,s:v.classStart,e:v.classEnd,rep:v.classDays});
 // Generate tomorrow's subject tasks in free slots around the class and existing activities.
 S.acts=S.acts.filter(a=>!(a.autoForDate===dt));let start=8*60,finish=21*60;const duration=S.set.studyMins;
 for(let i=0;i<subs.length;i++){let slot=null;for(let m=start;m+duration<=finish;m+=5){const st=pad(Math.floor(m/60))+':'+pad(m%60),enM=m+duration,en=pad(Math.floor(enM/60))+':'+pad(enM%60);const clash=items(dt).some(x=>{const xs=mm(x.s),xe=x.e?mm(x.e):xs+30;return m<xe&&enM>xs});if(!clash){slot={s:st,e:en};break}}
 if(slot){S.acts.push({id:'autoTomorrow'+Date.now()+'_'+i,name:'AI Study: '+subs[i],cat:'study',date:dt,s:slot.s,e:slot.e,rem:5,rep:[],pri:i===0?'high':'normal',notes:'Suggested by Smart Routine Coach. Edit freely around classes and rest.',autoForDate:dt,subject:subs[i]});start=mm(slot.e)+15}}
 S.set.tomorrowPlanMade=dt;save();render();alert('Tomorrow’s plan is ready! I added your class and created '+subs.length+' subject task(s) where free time was available. Please review the times and adjust anything that does not fit.');
 },'Create tomorrow plan');
}
'''
s=s.replace(marker,insert+marker)
# add button in sleep activity card
needle="b+=B('edit','✏')+B('re','↪')+B('rp','🔄')+(pr?'':B('skip','⏭'))+B('del','🗑');"
s=s.replace(needle, needle+"if(c==='sleep'&&/sleep/i.test(nm))b+='<button class=\"b p\" onclick=\"planTomorrow()\">🌙 Plan tomorrow</button>';" )
# update coach text and make button accessible in study screen
s=s.replace('Uses your saved tasks and completion progress. This is a private, rule-based coach—not a cloud generative AI model, and it needs no API key.', 'A lightweight on-device planning assistant: it checks your tasks, class times and free slots. Private and offline; no paid AI key needed.')
# add class schedule planner settings link
s=s.replace("'<div class=\"card\"><b>Profile & study setup</b>", "'<div class=\"card\"><b>Class schedule & Smart Planner</b><div class=\"sub\">Set class hours, then use Plan tomorrow on your Sleep activity to generate a realistic study plan.</div><div class=\"acts\"><button class=\"b p\" onclick=\"planTomorrow()\">🌙 Plan tomorrow now</button></div></div><div class=\"card\"><b>Profile & study setup</b>")
p.write_text(s)
