# Daily Routine Tracker v5.0 — Prayer, Theme & Smart Coach

Personalised routine planner and study focus timer built with HTML/CSS/JavaScript and Capacitor Android.

## Build an APK with GitHub Actions
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Ensure `.github/workflows/done.yml` is included.
3. Open **Actions** and run **Build Daily Routine Tracker APK**, or push to `main` / `master`.
4. When the workflow succeeds, open the run and download the `Daily-Routine-Tracker-APK` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on an Android device.

## Current features
- Profile setup: name, age, religion, grade, stream and subjects.
- Starter study tasks based on the selected subjects (editable by the user).
- Study dashboard, saved daily study plan, smart on-device routine coach, and a realistic mini-plan builder.
- Automatic prayer timetable for a user-entered city/country via AlAdhan; refreshes each day while online, displays all five prayers plus sunrise, and can update matching prayer activities. No GPS permission is used.
- New Aurora Emerald, Warm Sunset, and Midnight Violet themes.
- Full-screen focus timer, screen wake-lock request, optional generated rain-like ambience, and native Android AccessibilityService-based focus blocking (opt-in).
- Activity creation suggests the next available time and detects overlapping scheduled activities, offering to move the new activity to the next free slot.
- Goal setting and progress tracking, existing activity scheduling, completion/late status, calendar, weekly view, reminders and JSON backup.

## Focus blocking: explicit permission and limitations
- On Android APK, tap **Start focus session → Set up app blocking** and enable **Daily Routine Tracker Focus Blocking** in Android Accessibility settings. The user must enable this system permission manually; the app cannot grant it itself.
- While the timer is actively running, the accessibility service redirects foreground apps to Home, except essential phone/system/settings apps and this tracker. Pausing or ending the timer disables blocking.
- Android Accessibility-based blocking is a focus aid, not tamper-proof parental/device-owner kiosk mode: users can disable the permission, and behavior can vary by Android vendor. It does not read screen text or capture content. Do not enable accessibility services for apps you do not trust.
- The study coach is rule-based/offline, not a cloud generative AI service and does not require an API key.
- User data is stored locally in the app's browser storage. Export a JSON backup before clearing app data or reinstalling.
- The workflow builds a debug APK, not a production-signed release.


## Prayer timetable notes
- Default city is Negombo, Sri Lanka; edit it in More → Settings → Automatic prayer timetable.
- The app requests prayer times from the AlAdhan API and requires an internet connection to refresh. Cached/previous times remain if fetching fails.
- Calculation methods can differ from local mosque timetables; choose a method and verify prayer times locally. The app does not request location permission.


## Build workflow fix

The workflow now creates `www/index.html` before `npx cap add android`. Capacitor requires the configured `webDir` to exist before the Android platform is created; skipping this step can make the workflow fail early (sometimes surfaced as exit code 254). The workflow also enables Gradle stack traces. Upload the ZIP contents to the repository root (not the ZIP file itself), then run **Actions → Build Daily Routine Tracker APK → Run workflow**.
